package controller;

import model.Polynomial;
import view.Interface;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {
    private Polynomial pol;
    private Polynomial bol;
    private Interface inter;
    public Controller(Polynomial model, Interface view) {
        pol = model;
        inter = view;

        view.addEgalListener(new EgalListener());
        view.addDeleteListener(new DeleteListener());
        view.addAdunareListener(new AdunareListener());
        view.addScadereListener(new ScadereListener());
    }

    public class ScadereListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            inter.setRez(pol.scadere(inter.primul(), inter.doi()));
        }
    }

    public class EgalListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            pol.create(inter.primul());
            inter.setRez(inter.primul());
        }
    }

    public class DeleteListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            inter.stergeTot();
        }
    }

        public class AdunareListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
           inter.setRez(pol.adunare(inter.primul(), inter.doi()));
        }
    }

}
