package model;

import java.util.ArrayList;
import java.util.Collection;

public class Polynomial {
    ArrayList<Monomial> poly=new ArrayList<>();

    public void adMon(Monomial mon){
        poly.add(mon);
    }

    public ArrayList<Monomial> create(String poli) {
        ArrayList<String> polynomial = new ArrayList<>();
        ArrayList<Monomial> result = new ArrayList<>();
        polynomial.add(poli);
        //polynomial.add("X^5+3X^3");
        String[] polinom = new String[100];
        Monomial m[] = new Monomial[100];

        for(String s: polynomial){ // for(String a = polynomial ; a != NULL; a = a->next)
            polinom = s.split("\\+");
        }
        for(int i=0; i<10;i++){
            m[i] = new Monomial(0,0);
        }

        String[] cp = new String[100];
        String coeficient;
        String put;
        int i=0;

        for(String s: polinom) {
            if (!(s.contains("-"))) {
                if (s.contains("^")) {
                    coeficient = s.substring(0, 1);
                    if (coeficient.equals("X")) {
                        coeficient = String.valueOf('1');
                    }
                    int pol1 = s.indexOf("^");
                    put = s.substring(pol1 + 1);
                    m[i].setCoef(Integer.parseInt(coeficient));
                    m[i++].setPower(Integer.parseInt(put));
                } else {
                    if (s.contains("X") && !s.contains("^")) {
                        if(s.charAt(0) == 'X')
                            m[i].setCoef(1);
                        else
                        m[i].setCoef(Integer.parseInt(s.substring(0, 1)));
                        m[i++].setPower(1);
                    } else {
                        m[i].setCoef(Integer.parseInt(s));
                        m[i++].setPower(0);
                    }
                }
                result.add(m[i - 1]);
            }
            else
                if(s.contains("-")){
                    if (s.contains("^")) {
                        coeficient = s.substring(0, 1);
                        if (coeficient.equals("-")) {
                            int x = s.indexOf("X");
                            coeficient = s.substring(0,x);
                            if(coeficient.equals("-"))
                                coeficient = "-1";
                        }
                        int pol1 = s.indexOf("^");
                        put = s.substring(pol1 + 1);
                        m[i].setCoef(Integer.parseInt(coeficient));
                       // m[i].setCoef((-1)*m[i].getCoef());
                        m[i++].setPower(Integer.parseInt(put));
                    }
                    else {
                        if (s.contains("-X") && !s.contains("^")) {
                            m[i].setCoef(Integer.parseInt("-1"));
                            m[i++].setPower(1);
                        }
                        else
                            if(!(s.contains("^")) && !(s.contains("X"))){
                                coeficient = s.substring(0,2);
                                m[i].setCoef(Integer.parseInt(coeficient));
                                m[i++].setPower(0);

                            }
                            else if(!(s.contains("^")) && (s.contains("X"))){
                            coeficient = s.substring(0,2);
                            m[i].setCoef(Integer.parseInt(coeficient));
                            m[i++].setPower(1);
                        }

                        else {
                            m[i].setCoef(Integer.parseInt(s));
                            m[i++].setPower(0);
                        }

                    }
                    result.add(m[i - 1]);
        }
        }
        /*
        for(Monomial s: m){
            if(s.getCoef()!=0)
            System.out.println(s.getCoef() + " " + s.getPower());
        }*/
        return result;
    }


    public int gaseste(int cauta){
        for(int i=0;i<poly.size();i++){
           if(cauta == poly.get(i).getPower())
               return i;
        }
        return -1;
    }

    public String afis(ArrayList<Monomial> sir){
        String str1="";
        for(Monomial s: sir){
            if(s.getCoef()!=0){
                    if(s.getCoef() > 0)
                       /*   str1 = str1.concat("-");
                          else*/
                            str1 = str1.concat("+"); //-
                    if(s.getCoef() != 1)
                         str1 = str1.concat(String.valueOf(s.getCoef()));
                    if(s.getPower() > 0 ){
                        if(s.getPower() == 1 )
                            str1 = str1.concat("X");
                        else {
                            str1 = str1.concat("X^");
                            str1 = str1.concat(String.valueOf(s.getPower()));
                        }
                    }
                else
                    if(s.getCoef() <0 ){
                        str1 = str1.concat(String.valueOf(s.getCoef()));
                }

            }

        }
        if(str1.equals(""))
            return "0";
        if(str1.charAt(0) == '+')
            str1 = str1.substring(1);

        return str1;
    }


    public String adunare(String unu, String doi) {
        ArrayList<Monomial> primul = create(unu);
        ArrayList<Monomial> doilea = create(doi);

        ArrayList<Monomial> rezultat = new ArrayList<>();
        Polynomial rez = new Polynomial();
        Monomial monom = new Monomial(0,0);
        rezultat.addAll(primul);
        rezultat.addAll(doilea);

        for(int i=0; i< rezultat.size(); i++){
            for(int j=i+1; j< rezultat.size(); j++){
                if(rezultat.get(i).getPower() == rezultat.get(j).getPower()){
                    rezultat.get(i).setCoef(rezultat.get(i).getCoef() + rezultat.get(j).getCoef());
                    rezultat.remove(rezultat.get(j));
                }
            }
        }
        return afis(rezultat);
    }

    public String scadere(String unu,String doi) {
        ArrayList<Monomial> doilea = create(doi);

        for(Monomial i:doilea)
           i.setCoef(i.getCoef()*(-1));

        String doistring = afis(doilea);
        return adunare(unu,doistring);
    }
}
