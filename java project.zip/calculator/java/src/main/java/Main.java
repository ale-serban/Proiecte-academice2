// structure/calc-mvc/CalcMVC.java -- Calculator in MVC pattern.
// Fred Swartz -- December 2004
import controller.Controller;
import model.Polynomial;
import view.Interface;

import javax.swing.*;
public class Main {
    //... Create model, view, and controller. They are
    // created once here and passed to the parts that
    // need them so there is only one copy of each.
    public static void main(String[] args) {

       Polynomial model = new Polynomial();
       Interface view = new Interface(model);
       Controller controller = new Controller(model, view);
        view.method(view);
        view.setVisible(true);
    }
}