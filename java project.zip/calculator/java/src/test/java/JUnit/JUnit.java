package JUnit;
import model.Polynomial;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;


public class JUnit {

    @Test
    void AdditionTest() {
        Polynomial result = new Polynomial();
        assertEquals("2X^4+5X+2", result.adunare("X^4+2X", "X^4+3X+2"), "REZULTATUL ESTE: 2X^4+3X+2");
        assertEquals("0", result.adunare("-X^2", "X^2"), "REZULTATUL ESTE: 0");
        assertEquals("-2X^2", result.adunare("-3X^2", "X^2"), "REZULTATUL ESTE: -2X^2");
    }
    @Test
    void SubtractionTest(){
        Polynomial result = new Polynomial();
        assertEquals("3X^3+4X^2+7X", result.scadere("8X^3+4X^2+7X", "5X^3"), "REZULTATUL ESTE: 3X^3+4X^2+7X");
        assertEquals("0", result.scadere("X^2", "X^2"), "REZULTATUL ESTE: 0");
    }


}