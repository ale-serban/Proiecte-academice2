package dataLayer;

import business.DeliveryService;

import java.io.*;

public class Serializator implements Serializable {
    public static void serialize(DeliveryService d){
        try{
            FileOutputStream f=new FileOutputStream("file.ser");
            ObjectOutputStream out=new ObjectOutputStream(f);
            out.writeObject(d);
            out.close();
            f.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static DeliveryService deserialize() {
        DeliveryService deliveryService = new DeliveryService();
        try {
            FileInputStream file = new FileInputStream("file.ser");
            ObjectInputStream in = new ObjectInputStream(file);
            while (in.available() > 0) {
                deliveryService = (DeliveryService) in.readObject();
            }
            in.close();
            file.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return deliveryService;
    }

}
