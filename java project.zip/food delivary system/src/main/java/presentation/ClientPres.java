package presentation;

import business.DeliveryService;
import business.MenuItem;
import business.Order;
import dataLayer.FileWriterClass;
import dataLayer.Serializator;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;

public class ClientPres extends JFrame implements Serializable {

    private JPanel contentPane;
    private JTextField produs;
    private JTable table;
    private JTextField detaliu;
    private int total;
    private HashSet<MenuItem> produsecomandate;
    private String bill="";
    private Employee e;


    public ClientPres(String numeClient, DeliveryService ds) {
        e=new Employee(ds);
        produsecomandate=new HashSet<MenuItem>();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(110, 110, 657, 562);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        produs = new JTextField();
        produs.setFont(new Font("Calibri", Font.BOLD, 20));
        produs.setBounds(11, 82, 351, 40);
        contentPane.add(produs);
        produs.setColumns(11);

        JLabel lblNewLabel = new JLabel("Produs");
        lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 20));
        lblNewLabel.setBounds(11, 40, 117, 31);
        contentPane.add(lblNewLabel);


        JButton adauga = new JButton("Adauga produs");
        adauga.addActionListener(e -> {
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            int rand = table.getSelectedRow();
            String numev=model.getValueAt(rand, 0).toString();
            float ratingv=Float.parseFloat(model.getValueAt(rand, 1).toString());
            float caloriiv= Float.parseFloat(model.getValueAt(rand, 2).toString());
            float proteinev= Float.parseFloat(model.getValueAt(rand, 3).toString());
            float grasimiv= Float.parseFloat(model.getValueAt(rand, 4).toString());
            float sodiumv= Float.parseFloat(model.getValueAt(rand, 5).toString());
            float pretv= Float.parseFloat(model.getValueAt(rand, 6).toString());
            MenuItem m=new MenuItem(numev,ratingv,caloriiv,proteinev,grasimiv,sodiumv,pretv);

            produsecomandate.add(m);
            total+=pretv;
            JOptionPane.showMessageDialog(null,"s-a adaugat cu succes");
            Serializator.serialize(ds);
        });
        adauga.setFont(new Font("Calibri", Font.BOLD, 20));
        adauga.setBounds(11, 148, 205, 31);
        contentPane.add(adauga);

        JButton finalizare = new JButton("Finalizare");
        finalizare.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Order nou=new Order(total,numeClient);//LogInPres.idBill);
                ds.comanda(nou,produsecomandate);
                bill+="Bonul clientului "+numeClient+"\n";

                for(MenuItem m:produsecomandate)
                    bill+=m.toString()+"\n";

                bill+="Totalul este: " +total+"\n";
                FileWriterClass f=new FileWriterClass("Bonul clientului "+numeClient+".txt");
                f.writeToFile(bill);
                total=0;
                produsecomandate.clear();
                bill="";
                JOptionPane.showMessageDialog(null,"finalizare cu succes");
                Serializator.serialize(ds);
            }});
        
        finalizare.setFont(new Font("Calibri", Font.BOLD, 20));
        finalizare.setBounds(11, 209, 205, 31);
        contentPane.add(finalizare);

        DefaultComboBoxModel list = new DefaultComboBoxModel();
        list.addElement("Nume");
        list.addElement("Rating");
        list.addElement("Calorii");
        list.addElement("Proteine");
        list.addElement("Grasimi");
        list.addElement("Sodiu");
        list.addElement("Pret");
        JComboBox comboBox = new JComboBox(list);
        comboBox.setFont(new Font("Calibri", Font.BOLD, 20));
        comboBox.setBounds(407, 82, 169, 40);
        contentPane.add(comboBox);

        detaliu = new JTextField();
        detaliu.setFont(new Font("Calibri", Font.BOLD, 20));
        detaliu.setColumns(11);
        detaliu.setBounds(407, 139, 169, 40);
        contentPane.add(detaliu);

        JButton cauta = new JButton("Cauta");
        cauta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String cat = (String) comboBox.getSelectedItem();
                String det = detaliu.getText();
                List<MenuItem> nou = ds.gasesteProduse(cat, det);
                DefaultTableModel c = new DefaultTableModel();
                c.addColumn("Title");
                c.addColumn("Rating");
                c.addColumn("Calories");
                c.addColumn("Protein");
                c.addColumn("Fat");
                c.addColumn("Sodim");
                c.addColumn("Price");
                for (MenuItem m : nou) {
                    Vector row = new Vector();
                    row.add(m.getProdus());
                    row.add(m.getRating());
                    row.add(m.getCalorii());
                    row.add(m.getProteine());
                    row.add(m.getGrasimi());
                    row.add(m.getSodiu());
                    row.add(m.getPret());
                    c.addRow(row);
                }
                table.setModel(c);
            }
        });
        cauta.setFont(new Font("Calibri", Font.BOLD, 20));
        cauta.setBounds(407, 209, 169, 31);
        contentPane.add(cauta);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(11, 278, 624, 195);
        contentPane.add(scrollPane);
        scrollPane.setViewportView(table);
        JButton btnAfiseazaIntregMeniul = new JButton("Afiseaza meniul intreg");
        btnAfiseazaIntregMeniul.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                table = afisare(table);
            }
        });
        btnAfiseazaIntregMeniul.setFont(new Font("Calibri", Font.BOLD, 20));
        btnAfiseazaIntregMeniul.setBounds(162, 248, 269, 30);
        contentPane.add(btnAfiseazaIntregMeniul);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                int rand = table.getSelectedRow();
                produs.setText(model.getValueAt(rand, 0).toString());
            }
        });

        JButton btnNewButton = new JButton("Log out");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                LogInPres f = new LogInPres(ds);
                f.show();
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Calibri", Font.BOLD, 20));
        btnNewButton.setBounds(524, 485, 111, 31);
        contentPane.add(btnNewButton);
    }

    public JTable afisare(JTable t) {
        File csv = new File("products.csv");
        DefaultTableModel tab = new DefaultTableModel();
        try {
            int start = 0;
            InputStreamReader i = new InputStreamReader(new FileInputStream(csv));
            CSVParser csvParser = CSVFormat.DEFAULT.parse(i);
            for (CSVRecord csvRecord : csvParser) {
                if (start == 0) {
                    start = 1;
                    tab.addColumn(csvRecord.get(0));
                    tab.addColumn(csvRecord.get(1));
                    tab.addColumn(csvRecord.get(2));
                    tab.addColumn(csvRecord.get(3));
                    tab.addColumn(csvRecord.get(4));
                    tab.addColumn(csvRecord.get(5));
                    tab.addColumn(csvRecord.get(6));
                } else {
                    Vector row = new Vector();
                    row.add(csvRecord.get(0));
                    row.add(csvRecord.get(1));
                    row.add(csvRecord.get(2));
                    row.add(csvRecord.get(3));
                    row.add(csvRecord.get(4));
                    row.add(csvRecord.get(5));
                    row.add(csvRecord.get(6));
                    tab.addRow(row);
                }
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        t.setModel(tab);
        return t;
    }
}
