package presentation;

import business.DeliveryService;
import business.MenuItem;
import business.Order;

import javax.swing.*;
import java.util.HashSet;
import java.util.Observable;
import java.util.Observer;

public class Employee extends JFrame implements Observer {

    private DeliveryService ds;
    private JTextArea textList;
    private JLabel labelList;

    public Employee(DeliveryService ds){
        this.ds=ds;

        getContentPane().setLayout(null);
        this.setBounds(0, 0, 600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        labelList = new JLabel(" Lista comenzi");
        labelList.setBounds(10, 10, 200, 100);
        getContentPane().add(labelList);

        textList = new JTextArea();
        textList.setBounds(10, 98, 450, 347);
        this.setBounds(10, 300, 500, 500);
        getContentPane().add(textList);
    }

    public DeliveryService getDs() {
        return ds;
    }

    public void setDs(DeliveryService ds) {
        this.ds = ds;
    }

    @Override
    public void update(Observable o, Object arg) {
        DeliveryService d=(DeliveryService) o;
        Order com=(Order) arg;
        HashSet<MenuItem> prod=d.getProduseComandate().get(com);
        String s="Comanda "+com.toString()+"\n";
        s =s+"Produse \n";
        for(MenuItem m:prod){
            s+=m.toString()+"\n";
        }
        textList.setText(s);
    }
}
