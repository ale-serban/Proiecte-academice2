package presentation;

import business.DeliveryService;
import business.MenuItem;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Vector;

public class AdministratorPres extends JFrame {

    private JPanel contentPane;
    private JTextField nume;
    private JTextField rating;
    private JTextField calorii;
    private JTextField proteine;
    private JTextField grasimi;
    private JTextField sodium;
    private JTextField pret;
    private JTable table;
    private JTextField numeMeniu;
    private JLabel pretMeniu;
    private HashSet<MenuItem> meniuNou;
    int i=1;
    float p=0;


    public AdministratorPres(DeliveryService ds) {
        meniuNou=new HashSet<>();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(101, 101, 972, 689);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Produs");
        lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 20));
        lblNewLabel.setBounds(82, 31, 79, 31);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Nume");
        lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_1.setBounds(11, 71, 79, 27);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_11 = new JLabel("Rating");
        lblNewLabel_11.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_11.setBounds(11, 106, 79, 27);
        contentPane.add(lblNewLabel_11);

        JLabel lblNewLabel_12 = new JLabel("Calorii");
        lblNewLabel_12.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_12.setBounds(11, 141, 79, 27);
        contentPane.add(lblNewLabel_12);

        JLabel lblNewLabel_13 = new JLabel("Proteine");
        lblNewLabel_13.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_13.setBounds(11, 176, 79, 27);
        contentPane.add(lblNewLabel_13);

        JLabel lblNewLabel_14 = new JLabel("Grasimi");
        lblNewLabel_14.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_14.setBounds(11, 211, 79, 27);
        contentPane.add(lblNewLabel_14);

        JLabel lblNewLabel_15 = new JLabel("Sodium");
        lblNewLabel_15.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_15.setBounds(11, 246, 79, 27);
        contentPane.add(lblNewLabel_15);

        JLabel lblNewLabel_16 = new JLabel("Pret");
        lblNewLabel_16.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_16.setBounds(11, 281, 79, 27);
        contentPane.add(lblNewLabel_16);

        nume = new JTextField();
        nume.setFont(new Font("Calibri", Font.BOLD, 19));
        nume.setBounds(115, 71, 351, 27);
        contentPane.add(nume);
        nume.setColumns(10);

        rating = new JTextField();
        rating.setFont(new Font("Calibri", Font.BOLD, 19));
        rating.setColumns(10);
        rating.setBounds(115, 106, 157, 27);
        contentPane.add(rating);

        calorii = new JTextField();
        calorii.setFont(new Font("Calibri", Font.BOLD, 19));
        calorii.setColumns(10);
        calorii.setBounds(115, 141, 157, 27);
        contentPane.add(calorii);

        proteine = new JTextField();
        proteine.setFont(new Font("Calibri", Font.BOLD, 19));
        proteine.setColumns(10);
        proteine.setBounds(115, 176, 157, 27);
        contentPane.add(proteine);

        grasimi = new JTextField();
        grasimi.setFont(new Font("Calibri", Font.BOLD, 19));
        grasimi.setColumns(10);
        grasimi.setBounds(115, 211, 157, 27);
        contentPane.add(grasimi);

        sodium = new JTextField();
        sodium.setFont(new Font("Calibri", Font.BOLD, 19));
        sodium.setColumns(10);
        sodium.setBounds(115, 246, 157, 27);
        contentPane.add(sodium);

        pret = new JTextField();
        pret.setFont(new Font("Calibri", Font.BOLD, 19));
        pret.setColumns(10);
        pret.setBounds(115, 281, 157, 27);
        contentPane.add(pret);

        table = new JTable();
        table = afisare(table);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(22, 326, 909, 252);
        contentPane.add(scrollPane);
        scrollPane.setViewportView(table);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                int rand = table.getSelectedRow();
                nume.setText(model.getValueAt(rand, 0).toString());
                rating.setText(model.getValueAt(rand, 1).toString());
                calorii.setText(model.getValueAt(rand, 2).toString());
                proteine.setText(model.getValueAt(rand, 3).toString());
                grasimi.setText(model.getValueAt(rand, 4).toString());
                sodium.setText(model.getValueAt(rand, 5).toString());
                pret.setText(model.getValueAt(rand, 6).toString());
            }
        });

        JButton btnNewButton = new JButton("Log out");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                LogInPres f = new LogInPres( ds);
                f.show();
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Calibri", Font.BOLD, 19));
        btnNewButton.setBounds(817, 612, 114, 31);
        contentPane.add(btnNewButton);

        JButton adauga = new JButton("Adaugare");
        adauga.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String numep = nume.getText();
                Float pretp = Float.valueOf(pret.getText());
                Float caloriip = Float.valueOf(calorii.getText());
                Float proteinep = Float.valueOf(proteine.getText());
                Float grasimip = Float.valueOf(grasimi.getText());
                Float sodiup = Float.valueOf(sodium.getText());
                Float ratingp = Float.valueOf(rating.getText());
                MenuItem nou = new MenuItem(numep, ratingp, caloriip, proteinep, grasimip, sodiup,pretp);
                ds.adaugareMeniu(nou);
                table = afisare(table);
                JOptionPane.showMessageDialog(null,"s-au introdus cu succes datele");
            }
        });
        adauga.setFont(new Font("Calibri", Font.BOLD, 19));
        adauga.setBounds(324, 106, 122, 27);
        contentPane.add(adauga);

        JButton editare = new JButton("Editare");
        editare.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MenuItem vechi;
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                int rand = table.getSelectedRow();
                String numev=model.getValueAt(rand, 0).toString();
                float ratingv=Float.parseFloat(model.getValueAt(rand, 1).toString());
                float caloriiv= Float.parseFloat(model.getValueAt(rand, 2).toString());
                float proteinev= Float.parseFloat(model.getValueAt(rand, 3).toString());
                float grasimiv= Float.parseFloat(model.getValueAt(rand, 4).toString());
                float sodiumv= Float.parseFloat(model.getValueAt(rand, 5).toString());
                float pretv= Float.parseFloat(model.getValueAt(rand, 6).toString());
                vechi = new MenuItem(numev,ratingv,caloriiv,proteinev,grasimiv,sodiumv,pretv);

                MenuItem nou = new MenuItem(nume.getText(),  Float.valueOf(rating.getText()), Float.valueOf(calorii.getText()), Float.valueOf(proteine.getText()), Float.valueOf(grasimi.getText()), Float.valueOf(sodium.getText()),Float.valueOf(pret.getText()));
                ds.editareMeniu(vechi,nou);
                table = afisare(table);
                JOptionPane.showMessageDialog(null,"s-au editat cu succes datele");
            }
        });
        editare.setFont(new Font("Calibri", Font.BOLD, 19));
        editare.setBounds(323, 175, 121, 25);
        contentPane.add(editare);

        JButton stergere = new JButton("Stergere");
        stergere.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String numep = nume.getText();
                Float pretp = Float.valueOf(pret.getText());
                Float caloriip = Float.valueOf(calorii.getText());
                Float proteinep = Float.valueOf(proteine.getText());
                Float grasimip = Float.valueOf(grasimi.getText());
                Float sodiup = Float.valueOf(sodium.getText());
                Float ratingp = Float.valueOf(rating.getText());
                MenuItem nou = new MenuItem(numep,  ratingp, caloriip, proteinep, grasimip, sodiup,pretp);
                ds.stergereMeniu(nou);
                table = afisare(table);
                JOptionPane.showMessageDialog(null,"stergere cu succes");
            }
        });
        stergere.setFont(new Font("Calibri", Font.BOLD, 19));
        stergere.setBounds(324, 246, 122, 27);
        contentPane.add(stergere);


        JButton adInMeniu = new JButton("Adaugare in meniu");
        adInMeniu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MenuItem m = new MenuItem(nume.getText(),  Float.parseFloat(rating.getText()), Float.parseFloat(calorii.getText()),
                        Float.parseFloat(proteine.getText()), Float.parseFloat(grasimi.getText()), Float.parseFloat(sodium.getText()),
                        Float.parseFloat(pret.getText()));
                meniuNou.add(m);
                p = p + m.getPret()-2;
                pretMeniu.setText(String.valueOf(p));
                JOptionPane.showMessageDialog(null,"adaugare cu succes");
            }
        });
        adInMeniu.setFont(new Font("Calibri", Font.BOLD, 19));
        adInMeniu.setBounds(560, 68, 201, 31);
        contentPane.add(adInMeniu);

        JLabel lblNewLabel_17 = new JLabel("Nume meniu");
        lblNewLabel_17.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_17.setBounds(505, 115, 114, 27);
        contentPane.add(lblNewLabel_17);

        JLabel lblNewLabel_171 = new JLabel("Pret meniu");
        lblNewLabel_171.setFont(new Font("Calibri", Font.BOLD, 19));
        lblNewLabel_171.setBounds(505, 150, 114, 27);
        contentPane.add(lblNewLabel_171);

        numeMeniu = new JTextField();
        numeMeniu.setFont(new Font("Calibri", Font.BOLD, 19));
        numeMeniu.setColumns(10);
        numeMeniu.setBounds(628, 112, 157, 27);
        contentPane.add(numeMeniu);

        pretMeniu = new JLabel("");
        pretMeniu.setFont(new Font("Calibri", Font.BOLD, 19));
        pretMeniu.setBounds(628, 147, 157, 27);
        contentPane.add(pretMeniu);

        JButton btnFinalizareMeniu = new JButton("Finalizare meniu");
        btnFinalizareMeniu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ds.adaugareMeniuNou(numeMeniu.getText(),meniuNou);
                meniuNou=null;
                table=afisare(table);
                p=0;i=1;
                JOptionPane.showMessageDialog(null,"meniul nou s-a introdus cu succes");
            }
        });
        btnFinalizareMeniu.setFont(new Font("Calibri", Font.BOLD, 19));
        btnFinalizareMeniu.setBounds(560, 200, 201, 31);
        contentPane.add(btnFinalizareMeniu);

        JButton btnNewButton_1 = new JButton("Rapoarte");
        btnNewButton_1.addActionListener(e -> {
            ReportsPres r = new ReportsPres(ds);
            r.show();
            dispose();
        });
        btnNewButton_1.setFont(new Font("Calibri", Font.BOLD, 19));
        btnNewButton_1.setBounds(588, 245, 143, 37);
        contentPane.add(btnNewButton_1);
    }

    public JTable afisare(JTable t) {
        File csv = new File("products.csv");
        DefaultTableModel tab = new DefaultTableModel();
        try {
            int start = 0;
            InputStreamReader i = new InputStreamReader(new FileInputStream(csv));
            CSVParser csvParser = CSVFormat.DEFAULT.parse(i);
            for (CSVRecord csvRecord : csvParser) {
                if (start == 0) {
                    start = 1;
                    tab.addColumn(csvRecord.get(0));
                    tab.addColumn(csvRecord.get(1));
                    tab.addColumn(csvRecord.get(2));
                    tab.addColumn(csvRecord.get(3));
                    tab.addColumn(csvRecord.get(4));
                    tab.addColumn(csvRecord.get(5));
                    tab.addColumn(csvRecord.get(6));
                } else {
                    Vector row = new Vector();
                    row.add(csvRecord.get(0));
                    row.add(csvRecord.get(1));
                    row.add(csvRecord.get(2));
                    row.add(csvRecord.get(3));
                    row.add(csvRecord.get(4));
                    row.add(csvRecord.get(5));
                    row.add(csvRecord.get(6));
                    tab.addRow(row);
                }
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        t.setModel(tab);
        return t;
    }
}
