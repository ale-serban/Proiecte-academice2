package MVC;

import business.DeliveryService;
import dataLayer.Serializator;
import presentation.Employee;
import presentation.LogInPres;

public class Main {
    public static void main(String[] args) {
        DeliveryService ds = Serializator.deserialize();
        Employee e = new Employee(ds);
        ds.observerAdd(e);
        e.show();
        LogInPres f = new LogInPres(ds);
        f.setVisible(true);
    }
}
