package business;

public class BaseProduct extends MenuItem  {
    public BaseProduct(String nume, float rating, float calorii, float proteine, float grasimi, float sodiu,float pret)
    {super(nume,rating,calorii,proteine,grasimi,sodiu,pret);
    }

    @Override
    public void setProdus(String nume){
        super.setProdus(nume);
    }
    @Override
    public String getProdus() {
        return super.getProdus();
    }
    @Override
    public float getPret() {
        return super.getPret();
    }
    @Override
    public void setPret(float pret) {
        super.setPret(pret);
    }
    @Override
    public float getRating() {
        return super.getRating();
    }
    @Override
    public void setRating(float rating) {
        super.setRating(rating);
    }
    @Override
    public float getCalorii() {
        return super.getCalorii();
    }
    @Override
    public void setCalorii(float calorii) {
        super.setCalorii(calorii);
    }
    @Override
    public float getProteine() {
        return super.getProteine();
    }
    @Override
    public void setProteine(float proteine) {
        super.setProteine(proteine);
    }
    @Override
    public float getGrasimi() {
        return super.getGrasimi();
    }
    @Override
    public void setGrasimi(float grasimi) {
        super.setGrasimi(grasimi);
    }
    @Override
    public float getSodiu() {
        return super.getSodiu();
    }
    @Override
    public void setSodiu(float sodiu) {
        super.setSodiu(sodiu);
    }

}
