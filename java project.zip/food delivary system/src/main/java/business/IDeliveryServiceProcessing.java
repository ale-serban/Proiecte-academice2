package business;

import presentation.Employee;

import java.util.HashSet;
import java.util.List;

public interface IDeliveryServiceProcessing {
    //metodele de la deliveryService, doar antetul
    void stergereMeniu(MenuItem m);
    void editareMeniu(MenuItem m1,MenuItem m2);
    void adaugareMeniu(MenuItem m);
    void adaugareMeniuNou(String nume, HashSet<MenuItem> nou);
    void generareInterval(int ora1,int ora2);
    void generareRaport2(int times);
    void generareRaport3(int times,float total);
    void generareRaport4(int day);
    void comanda(Order o,HashSet<MenuItem> produse);
    List<MenuItem> gasesteProduse(String categorie, String detaliu);
    void observerAdd(Employee e);
}
