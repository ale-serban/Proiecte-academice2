package business;

import java.io.Serializable;
import java.util.Date;
import java.util.Observable;

public class Order extends Observable implements Serializable {
    private int id;
    private Date data;
    private static int idC = 1;
    private float pret;
    private String numeClient;

    public Order(float pret,String numeClient) {
        this.id = idC;
        data = new Date();
        this.numeClient = numeClient;
        this.pret = pret;
        idC++;
    }

    public String getNumeClient() {
        return numeClient;
    }

    public Date getData() {
        return data;
    }

    public float getPret() {
        return pret;
    }

    @Override
    public int hashCode() {
        return id;
    }

    public String toString(){
        return " client "+numeClient+" total "+pret+"\n";
    }

}
