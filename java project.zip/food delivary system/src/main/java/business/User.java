package business;

public class User {
    private String nume;
    private String parola;
    private int tip;//0-client; 1- admin

    public User(String nume, String parola,int tip){
        this.nume=nume;
        this.parola=parola;
        this.tip=tip;
    }

    public String getNume() {
        return nume;
    }
    public String getParola() {
        return parola;
    }
    public int getTip() {
        return tip;
    }

}
