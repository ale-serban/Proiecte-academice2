package business;

import java.util.HashSet;

public class CompositeProduct extends MenuItem {
    private HashSet<MenuItem> compunere;

    public CompositeProduct(HashSet<MenuItem> compunere, String nume,  float rating, float calorii, float proteine, float grasimi, float sodiu,float pret) {
        super(nume, rating, calorii, proteine, grasimi, sodiu,pret);
        this.compunere = new HashSet<MenuItem>();
    }

    @Override
    public void setProdus(String nume) {
        super.setProdus(nume);
    }

    @Override
    public String getProdus() {
        return super.getProdus();
    }

    @Override
    public float getPret() {
        return super.getPret();
    }

    @Override
    public void setPret(float pret) {
        super.setPret(pret);
    }

    @Override
    public float getRating() {
        float rating = 0;
        for (MenuItem m : compunere) {
            rating += m.getRating();
        }
        rating = rating / compunere.size();
        return rating;
    }

    @Override
    public void setRating(float rating) {
        super.setRating(rating);
    }

    @Override
    public float getCalorii() {
        float calorii = 0;
        for (MenuItem m : compunere) {
            calorii += m.getCalorii();
        }
        return calorii;
    }

    @Override
    public void setCalorii(float calorii) {
        super.setCalorii(calorii);
    }

    @Override
    public float getProteine() {
        float proteine = 0;
        for (MenuItem m : compunere) {
            proteine += m.getProteine();
        }
        return proteine;
    }

    @Override
    public void setProteine(float proteine) {
        super.setProteine(proteine);
    }

    @Override
    public float getGrasimi() {
        float grasimi = 0;
        for (MenuItem m : compunere) {
            grasimi += m.getGrasimi();
        }
        return grasimi;
    }

    @Override
    public void setGrasimi(float grasimi) {
        super.setGrasimi(grasimi);
    }

    @Override
    public float getSodiu() {
        float sodiu = 0;
        for (MenuItem m : compunere) {
            sodiu += m.getRating();
        }
        return sodiu;
    }

    @Override
    public void setSodiu(float sodiu) {
        super.setSodiu(sodiu);
    }
}
