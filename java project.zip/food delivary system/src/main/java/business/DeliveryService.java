package business;

import dataLayer.FileWriterClass;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import presentation.Employee;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class DeliveryService extends Observable implements IDeliveryServiceProcessing, Serializable {
    private HashMap<Order,HashSet<MenuItem>> produseComandate;
    private HashSet<MenuItem> meniu;
    private HashSet<Order> comenzi;

    public  DeliveryService(){
        meniu= new HashSet<MenuItem>();
        meniu();
        produseComandate=new HashMap<Order, HashSet<MenuItem>>();
        comenzi=new HashSet<Order>();
    }

    public HashMap<Order, HashSet<MenuItem>> getProduseComandate() {
        return produseComandate;
    }

    //parseaza csv-ul
    //csvRecord este o linie
    public void meniu(){
        File csv =new File("products.csv");
        try{
            int start=0;
            InputStreamReader i=new InputStreamReader(new FileInputStream(csv));
            CSVParser csvParser= CSVFormat.DEFAULT.parse(i);
            for(CSVRecord csvRecord:csvParser){
                //vreau sa trec direct la linie 2 ca sa nu iau linia cu atribute
                if(start==0){
                    start=1;
                }
                else{
                    Vector row=new Vector();
                    String n=csvRecord.get(0);
                    float rating= Float.parseFloat(csvRecord.get(1));
                    float calorii= Float.parseFloat(csvRecord.get(2));
                    float proteine= Float.parseFloat(csvRecord.get(3));
                    float grasimi= Float.parseFloat(csvRecord.get(4));
                    float sodiu= Float.parseFloat(csvRecord.get(5));
                    float pret= Float.parseFloat(csvRecord.get(6));
                    meniu.add(new MenuItem(n,rating,calorii,proteine,grasimi,sodiu,pret));
                }
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    //daca modific un produs se modifica si in csv
    //se suprascriu datele fisierului
    public void refreshCSV(){
        FileWriterClass f = new FileWriterClass("products.csv");
        String s = "Title,Rating,Calories,Protein,Fat,Sodium,Price\n";
        for(MenuItem m:meniu){
            s = s + m.toString()+"\n";
        }
        f.writeToFile(s);
    }

    @Override
    public void stergereMeniu(MenuItem m) {
        assert m!=null;
        assert wellFormed();
        int mSize=meniu.size();
        meniu.remove(m);
        refreshCSV();
        assert meniu.size() == mSize-1;
        assert wellFormed();
    }

    @Override
    public void editareMeniu(MenuItem m1, MenuItem m2) {
        assert m1!=null && m2!=null;
        assert wellFormed();
        int mSize=meniu.size();
        meniu.remove(m1);
        meniu.add(m2);
        refreshCSV();
        assert meniu.size()==mSize;
        assert wellFormed();
    }

    @Override
    public void adaugareMeniu(MenuItem m) {
        assert m!=null;
        assert wellFormed();
        int mSize=meniu.size();
        meniu.add(m);
        refreshCSV();
        assert meniu.size()==mSize+1;
        assert wellFormed();
    }

    @Override
    public void adaugareMeniuNou(String nume, HashSet<MenuItem> nou){
        assert nume!=null && nou!=null;
        assert wellFormed();
        int mSize=meniu.size();
        Float calorii = Float.valueOf(0),protein=Float.valueOf(0),grasimi=Float.valueOf(0),sodiu=Float.valueOf(0),rating=Float.valueOf(0),pret=Float.valueOf(0);
        for(MenuItem m:nou){
            calorii+=m.getCalorii();
            protein+=m.getProteine();
            grasimi+=m.getGrasimi();
            sodiu+=m.getSodiu();
            rating+=m.getRating();
            pret+=m.getPret()-2;
        }
        CompositeProduct produs=new CompositeProduct(nou, nume,rating/nou.size(), calorii, protein, grasimi, sodiu, pret);
        meniu.add(produs);
        refreshCSV();
        assert meniu.size()==mSize+1;
        assert wellFormed();
    }

    @Override
    public void comanda(Order o,HashSet<MenuItem> produse) {
        assert o!=null && produse!=null;
        assert wellFormed();
        comenzi.add(o);
        produseComandate.put(o,produse);
        //metode pt clasa employee pt a notifica employee ul ca s a fc o comanda
        setChanged();
        notifyObservers(o);
    }


    @Override
    public List<MenuItem> gasesteProduse(String categorie, String detaliu) {
        assert  categorie!= null && detaliu!=null;
        assert wellFormed();
        if (categorie.equals("Nume")) {
            return meniu.stream().filter(mi -> detaliu == null ||
                    mi.getProdus().toLowerCase().contains(detaliu.toLowerCase())).collect(Collectors.toList());
        } else if (categorie.equals("Rating")) {
            Float rating = Float.valueOf(detaliu);
            return meniu.stream().filter(mi -> rating == null || (mi instanceof MenuItem && Float.valueOf(((MenuItem) mi).getRating()).compareTo(rating) == 0)).collect(Collectors.toList());
        } else if (categorie.equals("Calorii")) {
            Float calories = Float.valueOf(detaliu);
            return meniu.stream().filter(mi -> calories == null || (mi instanceof MenuItem && Float.valueOf(((MenuItem) mi).getCalorii()).equals(calories))).collect(Collectors.toList());
        } else if (categorie.equals("Proteine")) {
            Float protein = Float.valueOf(detaliu);
            return meniu.stream().filter(mi -> protein == null || (mi instanceof MenuItem && Float.valueOf(((MenuItem) mi).getProteine()).equals(protein))).collect(Collectors.toList());
        } else if (categorie.equals("Grasimi")) {
            Float fats = Float.valueOf(detaliu);
            return meniu.stream().filter(mi -> fats == null || (mi instanceof MenuItem && Float.valueOf(((MenuItem) mi).getGrasimi()).equals(fats))).collect(Collectors.toList());
        } else if (categorie.equals("Sodiu")) {
            Float sodium = Float.valueOf(detaliu);
            return meniu.stream().filter(mi -> sodium == null || (mi instanceof MenuItem && Float.valueOf(((MenuItem) mi).getSodiu()).equals(sodium))).collect(Collectors.toList());
        } else if (categorie.equals("Pret")) {
            Float price = Float.valueOf(detaliu);
            return meniu.stream().filter(mi -> price == null || (mi instanceof MenuItem && Float.valueOf(((MenuItem)mi).getPret()).compareTo(price) == 0)).collect(Collectors.toList());
        }
        return null;
    }

    @Override
    public void generareInterval(int ora1,int ora2){
        assert ora1<ora2 &&ora1>=0&&ora2>=0&&ora1<=24&&ora2<=24;
        FileWriterClass f=new FileWriterClass("Raport Interval Timp.txt");
        String s="Comenzile plasate intre orele "+ora1+" - "+ora2+"\n\n";
        List<Order> c=comenzi.stream().filter(mi -> mi.getData().getHours()>=ora1 &&mi.getData().getHours()<=ora2).collect(Collectors.toList());

        for(Order i:c)
            s=s+i.toString()+"\n";

        f.writeToFile(s);
    }

    @Override
    public void generareRaport2(int times){
        assert times>0;
        FileWriterClass f=new FileWriterClass("Raport Produse.txt");
        String s="Produsele comandate de mai mult de  "+times+" ori \n\n";
        ArrayList<MenuItem> produse=new ArrayList<MenuItem>();
        for(Order o:comenzi){
            HashSet<MenuItem> prod=produseComandate.get(o);
            for(MenuItem m:prod){
                produse.add(m);
            }
        }

        //in obiect retin numele produsului
        //in long retin de cate ori apare un produs in comenda rspectiva
        //pereche <cheie, valoare>
        Map<Object, Long> count=produse.stream().collect(Collectors.groupingBy(p->p.getProdus(),Collectors.counting()));

        //scriu stringul intr un file
        for(Map.Entry<Object, Long> i: count.entrySet()){
            if(i.getValue()>=times){
                s = s + i.getKey()+" "+i.getValue()+"\n";
            }
        }
        f.writeToFile(s);
    }

    @Override
    public void generareRaport3(int times, float total) {
        assert times>0 && total>=0;
        FileWriterClass f=new FileWriterClass("Raport Clienti.txt");
        String s="Clientii care au comandat mai mult de  "+times+" ori \n\n numeClient -> nr comenzi\n\n";
        List<Order> c=comenzi.stream().filter(mi -> mi.getPret()>=total).collect(Collectors.toList());
        ArrayList<MenuItem> clienti=new ArrayList<MenuItem>();

        Map<Object, Long> count=c.stream().collect(Collectors.groupingBy(p->p.getNumeClient(),Collectors.counting()));

        for(Map.Entry<Object, Long> i: count.entrySet()){
            if(i.getValue()>=times){
                s=s+ i.getKey()+" -> "+i.getValue()+"\n";
            }
        }
        f.writeToFile(s);
    }

    @Override
    public void generareRaport4(int day) {
        assert day>=1&&day<=31;
        FileWriterClass f=new FileWriterClass("Raport Produse Zi.txt");
        String s="Produsele comandate in ziua de  "+day+" \n\n";
        List<Order> c=comenzi.stream().filter(mi -> mi.getData().getDay()==day).collect(Collectors.toList());
        ArrayList<MenuItem> produse=new ArrayList<MenuItem>();
        for(Order o:c){
            HashSet<MenuItem> prod=produseComandate.get(o);
            for(MenuItem m:prod){
                produse.add(m);
            }
        }
        Map<Object, Long> count=produse.stream().collect(Collectors.groupingBy(p->p.getProdus(),Collectors.counting()));

        for(Map.Entry<Object, Long> i: count.entrySet()){
            s=s+i.getKey()+" "+i.getValue()+"\n";
        }
        f.writeToFile(s);
    }

    public boolean wellFormed(){
        if(meniu==null || produseComandate==null || comenzi==null)
            return false;
        return true;
    }

    @Override
    public void observerAdd(Employee e) {
        this.addObserver(e);
    }
}
