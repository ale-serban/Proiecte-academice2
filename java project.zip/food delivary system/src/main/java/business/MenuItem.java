package business;

import java.io.Serializable;
import java.util.Objects;

public class MenuItem implements Serializable{

    private String produs;
    private float rating;
    private float calorii;
    private float proteine;
    private float grasimi;
    private float sodiu;
    private float pret;

    public MenuItem(String nume, float rating, float calorii, float proteine, float grasimi, float sodiu, float pret) {
        this.produs = nume;
        this.rating = rating;
        this.calorii = calorii;
        this.proteine = proteine;
        this.sodiu = sodiu;
        this.grasimi = grasimi;
        this.pret = pret;
    }


    public String getProdus() {
        return produs;
    }

    public void setProdus(String produs) {
        this.produs = produs;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public float getCalorii() {
        return calorii;
    }

    public void setCalorii(float calorii) {
        this.calorii = calorii;
    }

    public float getProteine() {
        return proteine;
    }

    public void setProteine(float proteine) {
        this.proteine = proteine;
    }

    public float getGrasimi() {
        return grasimi;
    }

    public void setGrasimi(float grasimi) {
        this.grasimi = grasimi;
    }

    public float getSodiu() {
        return sodiu;
    }

    public void setSodiu(float sodiu) {
        this.sodiu = sodiu;
    }

    @Override
    public int hashCode() {
        return Objects.hash(produs, rating, calorii, proteine, grasimi, sodiu, pret);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MenuItem menuItem = (MenuItem) o;
        return Float.compare(menuItem.rating, rating) == 0 && Float.compare(menuItem.calorii, calorii) == 0
                && Float.compare(menuItem.proteine, proteine) == 0 && Float.compare(menuItem.grasimi, grasimi) == 0
                && Float.compare(menuItem.sodiu, sodiu) == 0 && Double.compare(menuItem.pret, pret) == 0
                && Objects.equals(produs, menuItem.produs);
    }

    public String toString(){
        return produs+", "+rating+", "+calorii+", "+proteine+", "+grasimi+", "+sodiu+", "+pret;
    }
}
