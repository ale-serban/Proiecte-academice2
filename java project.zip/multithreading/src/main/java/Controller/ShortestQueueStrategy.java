package Controller;

import Controller.Strategy;
import Model.Server;
import Model.Task;

import java.util.ArrayList;

public class ShortestQueueStrategy implements Strategy {

    @Override
    public void addTask(ArrayList<Server> server, Task task) {
        int coada_min=9999;
        Server saux = new Server();
        for(Server s: server){
            if(s.getTask().size() < coada_min){
                coada_min = s.getTask().size();
                saux=s;
            }
        }
        saux.addTask(task);
    }
}
