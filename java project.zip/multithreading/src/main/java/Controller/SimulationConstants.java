package Controller;

import java.util.LinkedList;
import java.util.List;

public class SimulationConstants {
    static public int maxSimulationTime = 100;
    static public  int maxArrivalTime = 50;
    static public  int minArrivalTime = 2;
    static public  int maxServiceTime = 10;
    static public  int minServiceTime = 2;
    static public  int numberOfQueues = 3;
    static public  int numberOfClients = 100;
    static public List<String> simulationOutput = new LinkedList<String>();
    static public  int timy_mediu = 0;
}
