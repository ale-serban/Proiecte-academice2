package Controller;

import Controller.Strategy;
import Model.Server;
import Model.Task;

import java.util.ArrayList;

public class ShortestTimeStrategy implements Strategy {
    @Override
    public void addTask(ArrayList<Server> server, Task task) {
        int timp_min=9999;
        Server saux = new Server();
        for(Server s: server){
            if(s.getWaitingPeriod().intValue() < timp_min){
                timp_min = s.getWaitingPeriod().intValue();
                saux=s;
            }
        }
        saux.addTask(task);
    }
}
