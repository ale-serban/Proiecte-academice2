package Controller;

import Model.*;

import java.util.ArrayList;

public class Scheduler {
    private ArrayList<Server> serv = new ArrayList<>();
    private int nrserv;
    private int nrTaskS;
    private Strategy str;
    int i;

    public Scheduler(int nrserv, int nrTaskS){
        for(i=0; i<nrserv; i++){
            Server servire = new Server();
            Thread thread = new Thread(servire);
            thread.start();
            serv.add(servire);
        }
    }

    public void changeStrategy(SelectionPolicy policy){
        if(policy == SelectionPolicy.SHORTEST_QUEUE)
            str = new ShortestQueueStrategy();
        if(policy == SelectionPolicy.SHORTEST_TIME)
            str = new ShortestQueueStrategy();
    }

    public void dispatchTask(Task t){
        str.addTask(serv,t);
    }

    public ArrayList<Server> getServ() {
        return serv;
    }

    public void setServ(ArrayList<Server> serv) {
        this.serv = serv;
    }

    public int getNrserv() {
        return nrserv;
    }

    public void setNrserv(int nrserv) {
        this.nrserv = nrserv;
    }

    public int getNrTaskS() {
        return nrTaskS;
    }

    public void setNrTaskS(int nrTaskS) {
        this.nrTaskS = nrTaskS;
    }

    public Strategy getStr() {
        return str;
    }

    public void setStr(Strategy str) {
        this.str = str;
    }
}
