package Controller;

import Model.Task;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class SimulationManager implements Runnable{
    static public int timeLimit = 60;
    static public int minArrivalTime= 2;
    static public int maxArrivalTime= 40;
    static public int maxProcessingTime = 7;
    static public int minProcessingTime = 1;
    static public int numberOfServers = 5;
    static public int numberOfClients = 50;
    public SelectionPolicy selectionPolicy = SelectionPolicy.SHORTEST_TIME;

    private String string = "";
    private Scheduler scheduler;
    //private SimulationFrame frame;
    private ArrayList<Task> generatedTasks=new ArrayList<>();

    public SimulationManager(){
        this.scheduler = new Scheduler(numberOfServers,numberOfClients);
        scheduler.changeStrategy(selectionPolicy);
        generateNRandomTasks();
    }

    public SimulationManager(int timeLimit, int minArrivalTime, int maxArrivalTime, int maxProcessingTime, int minProcessingTime, int numberOfServers, int numberOfClients, SelectionPolicy selectionPolicy) {
        this.timeLimit = timeLimit;
        this.minArrivalTime = minArrivalTime;
        this.maxArrivalTime = maxArrivalTime;
        this.maxProcessingTime = maxProcessingTime;
        this.minProcessingTime = minProcessingTime;
        this.numberOfServers = numberOfServers;
        this.numberOfClients = numberOfClients;
        this.selectionPolicy = selectionPolicy;

        this.scheduler = new Scheduler(numberOfServers,numberOfClients);
        scheduler.changeStrategy(selectionPolicy);
        generateNRandomTasks();
    }

    private void generateNRandomTasks(){
        for(int i=1; i<=numberOfClients; i++){
            int arrival = ThreadLocalRandom.current().nextInt(minArrivalTime,maxArrivalTime);
            int services = ThreadLocalRandom.current().nextInt(minProcessingTime,maxProcessingTime+1);
            Task t= new Task(i, arrival, services);
            this.generatedTasks.add(t);
        }
    }

    public SimulationManager(int timeLimit, int maxProcessingTime, int minProcessingTime, int numberOfServers, int numberOfClients, SelectionPolicy selectionPolicy) {
        this.timeLimit = timeLimit;
        this.maxProcessingTime = maxProcessingTime;
        this.minProcessingTime = minProcessingTime;
        this.numberOfServers = numberOfServers;
        this.numberOfClients = numberOfClients;
        this.selectionPolicy = selectionPolicy;
    }

    @Override
    public void run() {
        int currentT = 1;

        while(currentT < timeLimit){
            System.out.print("\n");
            this.string = this.string.concat("\n");

            System.out.print("Timp: "+currentT+"\n");
            this.string = this.string.concat("Timp: "+currentT+"\n");

            System.out.print("In asteptare: ");
            this.string = this.string.concat("In asteptare: ");

            for(int i=0;i<3;i++) {
                if (generatedTasks.get(i) != null) {
                    System.out.print("(" + generatedTasks.get(i).getId() + "," + generatedTasks.get(i).getArrivalTime() + "," + generatedTasks.get(i).getServiceTime() + ") ");
                    this.string = this.string.concat("(" + generatedTasks.get(i).getId() + "," + generatedTasks.get(i).getArrivalTime() + "," + generatedTasks.get(i).getServiceTime() + ") ");
                }
            }
            System.out.print("\n");
            this.string = this.string.concat("\n");
            for(int i=0; i<numberOfServers; i++){
                System.out.print("Coada "+ (i+1) + ": ");
                this.string = this.string.concat("Coada "+ (i+1) + ": ");
                if (scheduler.getServ().get(i).getTask().isEmpty()) {
                    System.out.print("goala");
                    this.string = this.string.concat("goala");
                }
                else
                for(Task t1:scheduler.getServ().get(i).getTask()) {
                    if (t1 != null) {
                        System.out.print("(" + t1.getId() + "," + t1.getArrivalTime() + "," + t1.getServiceTime() + ") ");
                        this.string = this.string.concat("(" + t1.getId() + "," + t1.getArrivalTime() + "," + t1.getServiceTime() + ") ");
                    }
                }
                System.out.println("");
                System.out.print("");
                }

            int tcurr = currentT +1;
            ArrayList<Task> remove=new ArrayList<>();
            for(Task t: generatedTasks){
                if(t.getArrivalTime() == tcurr){
                    scheduler.dispatchTask(t);
                }
            }
            
            for(Task t: remove){
                    generatedTasks.remove(t);
                }

            currentT++;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }

        // open, write and close file
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter("log.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer.write(string);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args){
        SimulationManager gen= new SimulationManager();
        Thread t = new Thread(gen);
        t.start();
    }
}
