package Controller;

public enum SelectionPolicy {
    SHORTEST_QUEUE,SHORTEST_TIME
}
