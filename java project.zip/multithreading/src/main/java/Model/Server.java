package Model;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicInteger;

public class Server implements Runnable{
    private BlockingQueue<Task> task;
    private AtomicInteger waitingPeriod;
    int i;
    public Server(){
        this.task = new LinkedBlockingDeque<>();
        this.waitingPeriod = new AtomicInteger();
    }

    public void addTask(Task newT){
        task.add(newT);
        waitingPeriod.getAndAdd(newT.getServiceTime());
    }

    public BlockingQueue<Task> getTask() {
        return task;
    }

    public void setTask(BlockingQueue<Task> task) {
        this.task = task;
    }

    public AtomicInteger getWaitingPeriod() {
        return waitingPeriod;
    }

    public void setWaitingPeriod(AtomicInteger waitingPeriod) {
        this.waitingPeriod = waitingPeriod;
    }

    @Override
    public void run() {
        int k=2000;
        while(true)
        if(!task.isEmpty()){
            Task t = task.peek();
            if(t != null){
                int service = t.getServiceTime();
                    if(service > 0){
                   try {
                       Thread.sleep(k);
                   } catch (InterruptedException e) {
                       e.printStackTrace();
                   }
                        task.peek().setServiceTime(service-1);
                   k=1000;
                    }
                    if(service == 0){
                        task.remove();
                        for(i=0; i<t.getServiceTime(); i++)
                            this.waitingPeriod.getAndDecrement();
                    }
            }
            else k=2000;
        }
    }

}